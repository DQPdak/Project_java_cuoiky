package app.admin.entity;

public enum UserStatus {
    ACTIVE,
    LOCKED
}

