package app.admin.entity;

public enum Role {
    CANDIDATE,
    RECRUITER,
    ADMIN
}

