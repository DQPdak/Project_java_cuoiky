package app.admin.dto.response;

import app.admin.entity.Role;
import app.admin.entity.UserStatus;
import lombok.*;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class AdminUserResponse {
    private Long id;
    private String fullName;
    private String email;
    private Role role;
    private UserStatus status;
    private LocalDate createdAt;
}

